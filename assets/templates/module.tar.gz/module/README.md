# $NAME$ #

## installation: ##

### npm: ###
```
npm install $NAME$ --save
```

### yarn: ###
```
yarn add $NAME$
```

## usage: ##

```js
import default_export_from_the_module_being_used from '$NAME$';
```

or

```js
import { some_known_export_from_the_module_being_used } from '$NAME$';
```
