import { moduleName, moduleVersion } from "./module";

export { moduleName, moduleVersion };
