import { name, version } from "../package.json";

const moduleName = name;
const moduleVersion = version;

export { moduleName, moduleVersion };
