# $NAME$

$DESCRIPTION$

## installation:

### npm:

```
npm install -g $NAME$
```

### yarn:

```
yarn global add $NAME$
```

## usage:

After installation type **$BIN$ --help** for help

