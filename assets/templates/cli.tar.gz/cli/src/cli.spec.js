import { expect } from 'chai';
import { name, version, description } from '../package.json';
import { moduleName, moduleVersion, moduleDescription } from './morph-cli';

describe(name, () => {
  describe('moduleVersion', () => {
    it('is correct', () => {
      expect(moduleVersion).to.equal(version);
    });
  });
  describe('moduleName', () => {
    it('is correct', () => {
      expect(moduleName).to.equal(name);
    });
  });
  describe('moduleDecription', () => {
    it('is correct', () => {
      expect(moduleDescription).to.equal(description);
    });
  });
});
