const supportedColors = ['red', 'green', 'blue'];
const throwWhenUnsupportedColor = (color) => {
  if (!supportedColors.some(value => value === color)) {
    throw new Error(
      `Unsupported color: ${color}. Use one of the following: ${supportedColors
        .map(color => color)
        .join(', ')}`,
    );
  }
};

const handler = async (shortText, color) => {
  throwWhenUnsupportedColor(color);
  const text = `${figlet.textSync(shortText)}`;
  let colorText = text;
  switch(color){
    case 'red':
    colorText = chalk.red(text);
    break;
    case 'green':
    colorText = chalk.green(text);
    break;
    case 'blue':
    colorText = chalk.blue(text);
    break;
  }

  console.log(colorText); // eslint-disable-line no-console
};

export { supportedColors };
export default handler;
