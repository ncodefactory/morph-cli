/* eslint-disable no-console */
import program from 'commander';
import { name, version, description } from '../package.json';
import writeHandler, { supportedColors } from './write-handler';

const moduleName = name;
const moduleVersion = version;
const moduleDescription = description;

const run = async () => {
  program
    .version(moduleVersion)
    .command('write <shortText>')
    .description('shows entered text in a figlet font')
    .option('-c, --color [color]', 'color of the written figlet text')
    .action(async (shortText, options) => {
      try {
        await writeHandler(shortText, options.color);
      } catch (error) {
        console.log(`error: ${error.message}`);
      }
    })
    .on('--help', () => {
      console.log('');
      console.log('default color is your system terminal foreground color');
      console.log(
        `you can use three colors: ${supportedColors
          .map(color => color)
          .join(', ')}`,
      );
    });

  program.parse(process.argv);
  if (!process.argv.slice(2).length) {
    program.outputHelp();
  }
};

export { moduleName, moduleVersion, moduleDescription, run };
