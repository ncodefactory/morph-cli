# $NAME$

## installation:

### npm:

```
npm install $NAME$ --save
```

### yarn:

```
yarn add $NAME$
```

## usage:

```jsx
import React from "react";
import ReactDOM from "react-dom";
import { $COMPONENT_NAME$ } from "$NAME$";

ReactDOM.render(<$COMPONENT_NAME$ />, document.getElementById("root"));
```
