# $NAME$

## run:

```
npm run start
```

## debug (vscode only):

press F5 or click Start Debugging button
