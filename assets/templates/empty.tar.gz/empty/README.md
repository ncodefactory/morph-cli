# $NAME$

## run:

```
npm run start
```
## test:

```
npm run test
```

## debug (vscode only):

select launch configuration and press F5 or click Start Debugging button