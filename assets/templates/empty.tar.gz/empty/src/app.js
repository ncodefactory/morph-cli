import { moduleName, moduleVersion } from './app-module';

const message = `${moduleName} v${moduleVersion}`;
console.log(message); // eslint-disable-line no-console
