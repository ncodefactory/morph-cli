import { version } from '../package.json';

const moduleName = '$NAME$';
const moduleVersion = version;

export { moduleName, moduleVersion };
