# $NAME$

$DESCRIPTION$

**SSL support is available when application is running in Docker container only**

if you want use ssl in development mode read : https://medium.com/@danielgwilson/https-and-create-react-app-3a30ed31c904
