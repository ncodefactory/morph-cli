import React from 'react';
import { render } from '@testing-library/react';
import App from './App';
import { name, version, description } from '../package.json';

const content = `${name} ver. ${version} - ${description}`;
test('renders learn react link', () => {
  const { getByText } = render(<App />);
  const contentText = getByText(content);
  expect(contentText).toBeInTheDocument();
});
