import React from 'react';
import './App.scss';
import { name, version, description } from '../package.json';

function App() {
  const content = `${name} ver. ${version} - ${description}`;
  return <div>{content}</div>;
}

export default App;
