import React, { Component } from 'react';

class App extends Component {
  render() {
    return (
      <div>
        <b>$NAME$</b>
        <br />
        $DESCRIPTION$
      </div>
    );
  }
}

export default App;
