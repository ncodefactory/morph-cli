import React, { Component } from 'react';
import './App.scss';
import { name, version, description } from '../package.json';

const { ipcRenderer } = window.require('electron');

class App extends Component {
  state = {
    msgFromMainProcess: '',
  };

  componentDidMount() {
    ipcRenderer.on('fromMain', (_event, data) => {
      this.setState({ msgFromMainProcess: data.msg });
    });
  }

  onButtonClick = () => {
    ipcRenderer.send('fromRenderer', { msg: 'ping from renderer process' });
  };

  render() {
    const content = `${name} ver. ${version} - ${description}`;
    const { msgFromMainProcess } = this.state;
    return (
      <>
        <div>{content}</div>
        <button type="button" onClick={this.onButtonClick}>
          ping to main process
        </button>
        <p>{msgFromMainProcess}</p>
      </>
    );
  }
}

export default App;
