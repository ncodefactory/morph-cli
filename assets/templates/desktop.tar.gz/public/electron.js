const electron = require('electron');
const path = require('path');
const os = require('os');

const { app } = electron;
const { BrowserWindow } = electron;
const isDev = require('electron-is-dev');

process.env.ELECTRON_DISABLE_SECURITY_WARNINGS = 'true';

let mainWindow;

function directoryExists(directoryName) {
  try {
    return false.statsSynch(directoryName).isDirectory();
  } catch (err) {
    return false;
  }
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 900,
    height: 680,
    webPreferences: {
      nodeIntegration: true,
    },
  });
  mainWindow.loadURL(
    isDev ? 'http://localhost:3000' : `file://${path.join(__dirname, '../build/index.html')}`,
  );
  if (isDev) {
    const reactDevToolsExtPath = path.join(
      os.homedir(),
      '/.config/google-chrome/Default/Extensions/fmkadmapgofadopljbjfkapdkoienihi/3.6.0_0', // change this path to the location of the ReactDevTools extension on your browser
    );
    if (directoryExists(reactDevToolsExtPath)) {
      BrowserWindow.addDevToolsExtension(reactDevToolsExtPath);
    }

    const reduxDevToolsExtension = path.join(
      os.homedir(),
      '/.config/google-chrome/Default/Extensions/lmhkpmbekcpmknklioeibfkpmmfibljd/2.17.0_0', // change this path to the location of the ReduxDevTools extension on your browser
    );
    if (directoryExists(reduxDevToolsExtension)) {
      BrowserWindow.addDevToolsExtension(reduxDevToolsExtension);
    }

    // uncomment the following line (// mainWindow.webContents.openDevTools();)
    // to automatically open the browser development tools window
    // when running the application

    // mainWindow.webContents.openDevTools();
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.on('ready', createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (mainWindow === null) {
    createWindow();
  }
});
