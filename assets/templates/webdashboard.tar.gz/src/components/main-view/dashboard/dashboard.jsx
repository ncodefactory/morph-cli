import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import { Grid, GridItem } from '../../grid';
import Item1 from './item1/item1';
import Item2 from './item2/item2';
import Item3 from './item3/item1';

const useStyles = makeStyles(theme => ({
  paper: {
    padding: theme.spacing(2),
    display: 'flex',
    overflow: 'auto',
    flexDirection: 'column',
  },
}));

const Dashboard = () => {
  const classes = useStyles();
  return (
    <Grid spacing={2}>
      <GridItem xs={7}>
        <Paper className={classes.paper}>
          <Item1 />
        </Paper>
      </GridItem>
      <GridItem xs={5}>
        <Paper className={classes.paper}>
          <Item2 />
        </Paper>
      </GridItem>
      <GridItem xs={12}>
        <Paper className={classes.paper}>
          <Item3 />
        </Paper>
      </GridItem>
    </Grid>
  );
};

export default Dashboard;