import React from 'react';
import Divider from '@material-ui/core/Divider';
import Title from '../../../title';
import { Grid, GridItem } from '../../../grid';

const Item3 = () => {
  return (
    <Grid>
      <GridItem xs={11}>
        <Title>Item3</Title>
      </GridItem>
      <GridItem xs={12}>
        <Divider variant="fullWidth" />
      </GridItem>
    </Grid>
  );
};

export default Item3;