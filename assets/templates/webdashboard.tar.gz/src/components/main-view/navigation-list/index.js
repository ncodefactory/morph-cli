import NavigationList from './navigation-list';

export default NavigationList;
