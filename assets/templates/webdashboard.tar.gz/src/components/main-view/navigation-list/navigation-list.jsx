import React from 'react';
import PropTypes from 'prop-types';
import List from '@material-ui/core/List';
import { mdiViewDashboard, mdiTestTube } from '@mdi/js';
import env from '../../../environment';
import NavItem from './nav-item';

const NavigationList = ({ itemClick }) => {
  const handleClick = (title) => {
    if (itemClick) {
      itemClick(title);
    }
  };

  return (
    <List>
      <NavItem
        to="/"
        onClick={() => handleClick(`${env.APP_TITLE} - dashboard`)}
        text="Dashboard"
        path={mdiViewDashboard}
      />
      <NavItem
        to="/adhoc"
        onClick={() => handleClick(`${env.APP_TITLE} - adhoc`)}
        text="AdHoc"
        path={mdiTestTube}
        tooltip="development mode only"
      />
    </List>
  );
};

NavigationList.defaultProps = {
  itemClick: null,
};

NavigationList.propTypes = {
  itemClick: PropTypes.func,
};

export default NavigationList;
