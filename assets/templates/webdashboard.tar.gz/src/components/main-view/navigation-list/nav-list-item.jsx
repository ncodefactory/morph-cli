import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import clsx from 'clsx';
import { makeStyles } from '@material-ui/core/styles';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import Icon from '@mdi/react';
import { Tooltip } from '@material-ui/core';

const useStyles = makeStyles(theme => ({
  icon: {
    fill: theme.palette.grey.A700,
  },
  activeIcon: {
    fill: theme.palette.primary.main,
  },
  alignContent: {
    alignSelf: 'center',
  },
  activeListItem: {
    color: theme.palette.primary.main,
  },
}));

const NavListItem = ({
  path, text, tooltip, active, ...other
}) => {
  const classes = useStyles();
  return (
    <ListItem button component={Link} {...other}>
      <ListItemIcon
        classes={{
          root: clsx({ [classes.activeListItem]: active }),
        }}
      >
        <Icon path={path} size={1} className={active ? classes.activeIcon : classes.icon} />
      </ListItemIcon>
      {tooltip ? (
        <Tooltip title={tooltip}>
          <ListItemText
            classes={{
              primary: clsx({
                [classes.activeListItem]: active,
              }),
            }}
          >
            {text}
          </ListItemText>
        </Tooltip>
      ) : (
        <ListItemText
          classes={{
            primary: clsx({
              [classes.activeListItem]: active,
            }),
          }}
        >
          {text}
        </ListItemText>
      )}
    </ListItem>
  );
};

NavListItem.defaultProps = {
  active: false,
  path: null,
  tooltip: null,
};
NavListItem.propTypes = {
  tooltip: PropTypes.string,
  text: PropTypes.string.isRequired,
  active: PropTypes.bool,
  path: PropTypes.string,
};
export default NavListItem;
