import React from 'react';
import PropTypes from 'prop-types';
import { Switch, Route } from 'react-router-dom';
import NavListItem from './nav-list-item';

const NavItem = (props) => {
  const { to: linkTo } = props;
  return (
    <Switch>
      <Route exact path={linkTo} render={() => <NavListItem active {...props} />} />
      <Route path="/" render={() => <NavListItem {...props} />} />
    </Switch>
  );
};

NavItem.propTypes = {
  to: PropTypes.string.isRequired,
};

export default NavItem;
