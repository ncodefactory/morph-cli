import React from 'react';

const AdHoc = () => <></>;

export default AdHoc;
