import React from 'react';
import PropTypes from 'prop-types';
import Typography from '@material-ui/core/Typography';
import env from '../environment';

const Footer = ({ text }) => (
  <Typography variant="body2" color="textSecondary" align="center">
    {text}
  </Typography>
);

Footer.defaultProps = {
  text: env.APP_FOOTER,
};

Footer.propTypes = {
  text: PropTypes.string,
};

export default Footer;
