import React from 'react';
import GridBase from '@material-ui/core/Grid';

const Grid = props => <GridBase container {...props} />;
const GridItem = props => <GridBase item {...props} />;

export { Grid, GridItem };
