const environment = {
  APP_TITLE: process.env.REACT_APP_APP_TITLE || '$NAME$',
  APP_FOOTER: process.env.REACT_APP_APP_FOOTER || 'Copyright (c) $CURRENT_YEAR$ $AUTHOR_NAME$ ($AUTHOR_EMAIL$)',
};

export default environment;
