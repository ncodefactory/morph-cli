import React, { Component } from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import MainView from './components/main-view/main-view';

class App extends Component {
  render() {
    return (
      <Router>
        <MainView />
      </Router>
    );
    // const content = `${name} ver. ${version} - ${description}`;
    // return <div>{content}</div>;
  }
}

export default App;
