const setStringValue = (value, defaultStringValue) => value || defaultStringValue;
const setNumberValue = (value, defaultNumberValue) => {
  const numberValue = Number(value);
  return value == null || value === '' || Number.isNaN(value) || Number.isNaN(numberValue)
    ? defaultNumberValue
    : numberValue;
};
// eslint-disable-next-line no-unused-vars
const setBoolValue = (value, defaultBoolValue) => {
  const boolTrue = String(value).toLowerCase() === 'true';
  const boolFalse = String(value).toLowerCase() === 'false';

  return boolTrue || boolFalse ? !!boolTrue : defaultBoolValue;
};

const environment = {
  SERVER_HOST: setStringValue(process.env.REACT_APP_SERVER_HOST, '127.0.0.1'),
  SERVER_PORT: setNumberValue(process.env.REACT_APP_SERVER_PORT, 8090),
  SERVER_RECONNECT_INTERVAL: setNumberValue(
    process.env.REACT_APP_SERVER_RECONNECT_INTERVAL,
    60000,
  ),
  LOG_LEVEL: setNumberValue(process.env.REACT_APP_LOG_LEVEL || 1),
};

export default environment;
