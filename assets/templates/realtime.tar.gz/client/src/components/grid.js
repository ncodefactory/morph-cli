import React from 'react';
import Grid from '@material-ui/core/Grid';

const C = props => <Grid container {...props} />;
const I = props => <Grid item {...props} />;

export { C, I };
