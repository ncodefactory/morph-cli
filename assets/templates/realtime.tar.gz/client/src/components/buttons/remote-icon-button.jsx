import React from 'react';
import PropTypes from 'prop-types';
import { Tooltip } from '@material-ui/core';
import IconButton from '@material-ui/core/IconButton';
import Icon from '@mdi/react';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles(theme => ({
  icon: {
    fill: theme.palette.grey.A700,
  },
  disabledIcon: {
    fill: theme.palette.grey.A100,
  },
}));

const RemoteIconButton = ({
  serverWaiting, serverConnectionState, path, tooltip, ...props
}) => {
  const { dispatch: _, disabled, ...propsWithoutDispatch } = props;
  const reallyDisabled = disabled || serverWaiting || serverConnectionState !== 'OPEN';
  const classes = useStyles();
  if (tooltip) {
    return (
      <Tooltip title={tooltip}>
        <div>
          <IconButton disabled={reallyDisabled} {...propsWithoutDispatch}>
            <Icon
              path={path}
              className={reallyDisabled ? classes.disabledIcon : classes.icon}
              size={1}
            />
          </IconButton>
        </div>
      </Tooltip>
    );
  }
  return (
    <IconButton disabled={reallyDisabled} {...propsWithoutDispatch}>
      <Icon path={path} className={reallyDisabled ? classes.disabledIcon : classes.icon} size={1} />
    </IconButton>
  );
};

RemoteIconButton.defaultProps = {
  dispatch: null,
  path: null,
  tooltip: null,
  serverWaiting: false,
  disabled: false,
  serverConnectionState: 'unknown',
};

RemoteIconButton.propTypes = {
  serverWaiting: PropTypes.bool,
  path: PropTypes.string,
  serverConnectionState: PropTypes.string,
  tooltip: PropTypes.string,
  dispatch: PropTypes.func,
  disabled: PropTypes.bool,
};

export default RemoteIconButton;
