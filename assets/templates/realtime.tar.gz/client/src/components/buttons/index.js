import { connect } from 'react-redux';
import Button from './remote-button';
import IconButton from './remote-icon-button';

const mapStateToProps = (state) => {
  const { serverWaiting } = state.serverInfo.serverInfo;
  const { serverConnectionState } = state.serverConnection.serverConnection;
  return {
    serverWaiting,
    serverConnectionState,
  };
};

const RemoteButton = connect(mapStateToProps)(Button);
const RemoteIconButton = connect(mapStateToProps)(IconButton);

export { RemoteButton, RemoteIconButton };
