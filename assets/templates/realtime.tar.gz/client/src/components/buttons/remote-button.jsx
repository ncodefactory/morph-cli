import React from 'react';
import PropTypes from 'prop-types';
import Button from '@material-ui/core/Button';

const RemoteButton = ({ serverWaiting, serverConnectionState, ...props }) => {
  const { dispatch: _, disabled, ...propsWithoutDispatch } = props;
  const reallyDisabled = disabled || serverWaiting || serverConnectionState !== 'OPEN';
  return <Button disabled={reallyDisabled} {...propsWithoutDispatch} />;
};

RemoteButton.defaultProps = {
  dispatch: null,
  serverWaiting: false,
  disabled: false,
};

RemoteButton.propTypes = {
  serverConnectionState: PropTypes.string.isRequired,
  serverWaiting: PropTypes.bool,
  dispatch: PropTypes.func,
  disabled: PropTypes.bool,
};

export default RemoteButton;
