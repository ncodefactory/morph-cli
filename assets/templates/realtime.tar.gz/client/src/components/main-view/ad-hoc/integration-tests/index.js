import { connect } from 'react-redux';
import { changeServerWorkMode, testServerError } from '../../../../store/remote-actions';
import IntegrationTests from './integration-tests';

const mapStateToProps = (state) => {
  const { serverWorkMode } = state.serverInfo.serverInfo;
  return {
    serverWorkMode,
  };
};

const mapDispatchToProps = { changeServerWorkMode, testServerError };

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(IntegrationTests);
