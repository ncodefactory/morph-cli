import React from 'react';
import PropTypes from 'prop-types';
import Divider from '@material-ui/core/Divider';
import Typography from '@material-ui/core/Typography';
import { RemoteButton } from '../../../buttons';
import { C, I } from '../../../grid';
import Title from '../../../title';
import { ServerWorkModes } from '../../../../dictionaries';

const IntegrationTests = ({ serverWorkMode, changeServerWorkMode, testServerError }) => (
  <>
    <Title>Integration tests</Title>
    <Divider variant="fullWidth" />
    <C spacing={1}>
      <I xs={12}>
        <Typography variant="h3" align="center">
          {serverWorkMode}
        </Typography>
      </I>
      <I xs={12}>
        <RemoteButton
          fullWidth
          variant="contained"
          color="primary"
          onClick={() => changeServerWorkMode(
            serverWorkMode === ServerWorkModes.ADMIN ? ServerWorkModes.USER : ServerWorkModes.ADMIN,
          )
          }
        >
          Test ACTION workflow
        </RemoteButton>
      </I>
      <I xs={12}>
        <RemoteButton
          fullWidth
          variant="contained"
          color="secondary"
          onClick={() => testServerError()}
        >
          Test ERROR workflow
        </RemoteButton>
      </I>
    </C>
  </>
);

IntegrationTests.defaultProps = {
  serverWorkMode: null,
};

IntegrationTests.propTypes = {
  serverWorkMode: PropTypes.string,
  changeServerWorkMode: PropTypes.func.isRequired,
  testServerError: PropTypes.func.isRequired,
};

export default IntegrationTests;
