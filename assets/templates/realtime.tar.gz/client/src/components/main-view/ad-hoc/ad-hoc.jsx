import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import clsx from 'clsx';
import Paper from '@material-ui/core/Paper';
import IntegrationTests from './integration-tests';

const useStyles = makeStyles(theme => ({
  paper: {
    padding: theme.spacing(2),
    display: 'flex',
    overflow: 'auto',
    flexDirection: 'column',
  },
}));

const AdHoc = () => {
  const classes = useStyles();
  const fixedHeightPaper = clsx(classes.paper);
  return (
    <Paper className={fixedHeightPaper}>
      <IntegrationTests />
    </Paper>
  );
};

export default AdHoc;
