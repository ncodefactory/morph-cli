import AdHoc from './ad-hoc';

export default AdHoc;
