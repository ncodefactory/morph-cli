import React from 'react';
import Icon from '@mdi/react';
import IconButton from '@material-ui/core/IconButton';
import { makeStyles } from '@material-ui/core/styles';
import { mdiServerNetwork, mdiServerNetworkOff } from '@mdi/js';
import PropTypes from 'prop-types';
import { Tooltip } from '@material-ui/core';

const useStyles = makeStyles(theme => ({
  icon: {
    fill: theme.palette.primary.contrastText,
  },
}));

const renderIcon = (connectionState, classes) => (connectionState && connectionState.toUpperCase().startsWith('OPEN') ? (
  <Icon className={classes.icon} path={mdiServerNetwork} size={1} />
) : (
    <Icon className={classes.icon} path={mdiServerNetworkOff} size={1} />
  ));

const ServerConnectionIndicatorWithTooltip = ({ serverConnectionState, pingServer }) => {
  const classes = useStyles();
  return (
    <Tooltip title={serverConnectionState}>
      <IconButton onClick={() => pingServer()}>
        {renderIcon(serverConnectionState, classes)}
      </IconButton>
    </Tooltip>
  );
};

ServerConnectionIndicatorWithTooltip.defaultProps = {
  serverConnectionState: null,
  pingServer: null,
};

ServerConnectionIndicatorWithTooltip.propTypes = {
  serverConnectionState: PropTypes.string,
  pingServer: PropTypes.func,
};

const ServerConnectionIndicatorWithoutTooltip = ({ serverConnectionState, pingServer }) => {
  const classes = useStyles();
  return (
    <IconButton onClick={() => pingServer()}>{renderIcon(serverConnectionState, classes)}</IconButton>
  );
};

ServerConnectionIndicatorWithoutTooltip.defaultProps = {
  serverConnectionState: null,
  pingServer: null,
};

ServerConnectionIndicatorWithoutTooltip.propTypes = {
  serverConnectionState: PropTypes.string,
  pingServer: PropTypes.func,
};

const ServerConnectionIndicator = ({ serverConnectionState, pingServer }) => (serverConnectionState ? (
  <ServerConnectionIndicatorWithTooltip
    serverConnectionState={serverConnectionState}
    pingServer={pingServer}
  />
) : (
    <ServerConnectionIndicatorWithoutTooltip
      serverConnectionState={serverConnectionState}
      pingServer={pingServer}
    />
  ));

ServerConnectionIndicator.defaultProps = {
  serverConnectionState: null,
  pingServer: null,
};

ServerConnectionIndicator.propTypes = {
  serverConnectionState: PropTypes.string,
  pingServer: PropTypes.func,
};

export default ServerConnectionIndicator;
