import { connect } from 'react-redux';
import ServerConnectionIndicator from './server-connection-indicator';
import { pingServer } from '../../../store/remote-actions';

const mapStateToProps = (state) => {
  const { serverConnectionState } = state.serverConnection.serverConnection;
  return {
    serverConnectionState,
  };
};

const mapDispatchToProps = { pingServer };

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(ServerConnectionIndicator);
