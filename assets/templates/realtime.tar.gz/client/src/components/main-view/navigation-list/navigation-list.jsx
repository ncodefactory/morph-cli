import React from 'react';
import PropTypes from 'prop-types';
import List from '@material-ui/core/List';
import { mdiViewDashboard, mdiTestTube, mdiTuneVertical } from '@mdi/js';
import NavItem from './nav-item';

const NavigationList = ({ itemClick }) => {
  const handleClick = (title) => {
    if (itemClick) {
      itemClick(title);
    }
  };

  return (
    <List>
      <NavItem
        to="/"
        onClick={() => handleClick('$NAME$ - dashboard')}
        text="Dashboard"
        path={mdiViewDashboard}
      />
      <NavItem
        to="/settings"
        onClick={() => handleClick('$NAME$ - settings')}
        text="Settings"
        path={mdiTuneVertical}
      />
      <NavItem
        to="/adhoc"
        onClick={() => handleClick('$NAME$ - adhoc')}
        text="AdHoc"
        path={mdiTestTube}
        tooltip="development mode only"
      />
    </List>
  );
};

NavigationList.defaultProps = {
  itemClick: null,
};

NavigationList.propTypes = {
  itemClick: PropTypes.func,
};

export default NavigationList;
