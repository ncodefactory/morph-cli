import { connect } from 'react-redux';
import { connectToServer } from '../../store/server-connection/actions';
import MainView from './main-view';

const mapStateToProps = (state) => {
  const { serverEngine } = state.serverInfo.serverInfo;
  const { serverConnectionState } = state.serverConnection.serverConnection;
  return {
    serverEngine,
    serverConnectionState,
  };
};
const mapDispatchToProps = { connectToServer };
export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(MainView);
