import React from 'react';
import PropTypes from 'prop-types';
import Dialog from '@material-ui/core/Dialog';
import Typography from '@material-ui/core/Typography';
import Divider from '@material-ui/core/Divider';
import { DialogContent } from '@material-ui/core';
import env from '../../environment';
import { C, I } from '../grid';

const ServerConnectionBrokenInfo = ({ serverConnectionState }) => (
  <Dialog
    open={serverConnectionState !== 'OPEN'}
    aria-labelledby="server-connection-broken_title"
    aria-describedby="alert-dialog-description"
    disableBackdropClick
    disableEscapeKeyDown
  >
    <DialogContent>
      <C>
        <I xs={12}>
          <Typography variant="h6" align="center">
            {`Server connection ${serverConnectionState}`}
          </Typography>
        </I>
        <I xs={12}>
          <Divider variant="middle" />
        </I>
        <I xs={12} align="center">
          <Typography gutterBottom variant="caption">
            {`${env.SERVER_HOST}:${env.SERVER_PORT}`}
          </Typography>
        </I>
      </C>
    </DialogContent>
  </Dialog>
);

ServerConnectionBrokenInfo.propTypes = {
  serverConnectionState: PropTypes.string.isRequired,
};

export default ServerConnectionBrokenInfo;
