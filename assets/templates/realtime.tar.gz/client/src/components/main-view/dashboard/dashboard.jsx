import React from 'react';

const Dashboard = () => <></>;

export default Dashboard;
