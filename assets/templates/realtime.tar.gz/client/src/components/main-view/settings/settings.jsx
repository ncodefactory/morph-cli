import React from 'react';

const Diagnosis = () => <></>;

export default Diagnosis;
