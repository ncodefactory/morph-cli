import Settings from './settings';

export default Settings;
