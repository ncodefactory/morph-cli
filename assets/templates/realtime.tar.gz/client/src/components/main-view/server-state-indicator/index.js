import { connect } from 'react-redux';
import { clearServerError } from '../../../store/remote-actions';
import ServerStateIndicator from './server-state-indicator';

const mapStateToProps = (state) => {
  const { serverState, serverError } = state.serverInfo.serverInfo;
  return {
    serverState,
    serverError,
  };
};

const mapDispatchToProps = { clearServerError };

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(ServerStateIndicator);
