import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Icon from '@mdi/react';
import IconButton from '@material-ui/core/IconButton';
import { mdiSettings, mdiAlertOctagon } from '@mdi/js';
import PropTypes from 'prop-types';
import { Tooltip } from '@material-ui/core';

const useStyles = makeStyles(theme => ({
  icon: {
    fill: theme.palette.primary.contrastText,
  },
}));

const renderIcon = (serverState, classes) => {
  if (serverState && serverState.toUpperCase().startsWith('ERROR')) {
    return <Icon className={classes.icon} path={mdiAlertOctagon} size={1} />;
  }
  if (serverState && serverState.toUpperCase().startsWith('BUSY')) {
    return <Icon className={classes.icon} path={mdiSettings} size={1} spin />;
  }

  return <Icon className={classes.icon} path={mdiSettings} size={1} />;
};

const ServerStateIndicatorWithTooltip = ({ serverState, serverError, clearServerError }) => {
  const classes = useStyles();
  return (
    <div className={classes.root}>
      <div className={classes.wrapper}>
        <Tooltip title={serverError || serverState}>
          {serverState && serverState.toUpperCase().startsWith('ERROR') ? (
            <IconButton onClick={() => clearServerError()}>{renderIcon(serverState, classes)}</IconButton>
          ) : (
              <IconButton>{renderIcon(serverState, classes)}</IconButton>
            )}
        </Tooltip>
      </div>
    </div>
  );
};

ServerStateIndicatorWithTooltip.defaultProps = {
  serverState: null,
  serverError: null,
  clearServerError: null,
};

ServerStateIndicatorWithTooltip.propTypes = {
  serverState: PropTypes.string,
  serverError: PropTypes.string,
  clearServerError: PropTypes.func,
};

const ServerStateIndicatorWithoutTooltip = ({ serverState, clearServerError }) => {
  const classes = useStyles();
  return (
    <div className={classes.root}>
      <div className={classes.wrapper}>
        {serverState && serverState.toUpperCase().startsWith('ERROR') ? (
          <IconButton onClick={() => clearServerError()}>{renderIcon(serverState, classes)}</IconButton>
        ) : (
            <IconButton>{renderIcon(serverState, classes)}</IconButton>
          )}
      </div>
    </div>
  );
};

ServerStateIndicatorWithoutTooltip.defaultProps = {
  serverState: null,
  clearServerError: null,
};

ServerStateIndicatorWithoutTooltip.propTypes = {
  ServerState: PropTypes.string,
  clearServerError: PropTypes.func,
};

const ServerStateIndicator = ({ serverState, serverError, clearServerError }) => (serverError || serverState ? (
  <ServerStateIndicatorWithTooltip
    serverState={serverState}
    serverError={serverError}
    clearServerError={clearServerError}
  />
) : (
    <ServerStateIndicatorWithoutTooltip
      serverState={serverState}
      serverError={serverError}
      clearServerError={clearServerError}
    />
  ));

ServerStateIndicator.defaultProps = {
  serverState: null,
  serverError: null,
  clearServerError: null,
};

ServerStateIndicator.propTypes = {
  serverState: PropTypes.string,
  serverError: PropTypes.string,
  clearServerError: PropTypes.func,
};

export default ServerStateIndicator;
