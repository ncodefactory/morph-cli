import React from 'react';
import PropTypes from 'prop-types';
import Typography from '@material-ui/core/Typography';

const Footer = ({ text }) => (
  <Typography variant="body2" color="textSecondary" align="center">
    {text}
  </Typography>
);

Footer.defaultProps = {
  text: '$NAME$',
};

Footer.propTypes = {
  text: PropTypes.string,
};

export default Footer;
