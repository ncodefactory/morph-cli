import { createStore, applyMiddleware, compose } from 'redux';
import { devToolsEnhancer } from 'redux-devtools-extension';
import thunk from 'redux-thunk';
import { persistStore, persistReducer } from 'redux-persist';
import storage from 'redux-persist/lib/storage';
import rootReducer from './reducers';
import remoteActionsRouter from './remote-actions-router-middleware';
import { setClientId } from './client-id/actions';
import { getClientId } from './client-id/api';

const persistConfig = {
  key: '$NAME$-client',
  storage,
};
const persistedReducer = persistReducer(persistConfig, rootReducer);

const store = createStore(
  persistedReducer,
  compose(
    applyMiddleware(remoteActionsRouter),
    applyMiddleware(thunk),
    devToolsEnhancer(),
  ),
);

store.dispatch(setClientId(getClientId()));

const persistor = persistStore(store);

export { store, persistor };
