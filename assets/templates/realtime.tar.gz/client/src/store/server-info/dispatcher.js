import {
  setServerState, setServerError, setServerWorkMode, setServerEngine, setServerWaiting,
} from './actions';
import { ServerStates } from '../../dictionaries';

const broadcast = (serverInfo, dispatch) => {
  dispatch(setServerError(serverInfo.error));
  dispatch(setServerState(serverInfo.state));
  dispatch(setServerWorkMode(serverInfo.mode));
  dispatch(setServerEngine(serverInfo.engine));
  dispatch(setServerWaiting(serverInfo.state !== ServerStates.IDLE));
};

export default broadcast;
