import { combineReducers } from 'redux';
import { ActionTypes } from './actions';

const initialState = {};

const serverInfo = (state = initialState, { type, payload }) => {
  switch (type) {
    case ActionTypes.SET_SERVER_STATE:
      return { ...state, serverState: payload };
    case ActionTypes.SET_SERVER_ERROR:
      return { ...state, serverError: payload };
    case ActionTypes.SET_SERVER_WORK_MODE:
      return { ...state, serverWorkMode: payload };
    case ActionTypes.SET_SERVER_ENGINE:
      return { ...state, serverEngine: payload };
    case ActionTypes.SET_SERVER_WAITING:
      return { ...state, serverWaiting: payload };
    default:
      return state;
  }
};

export default combineReducers({ serverInfo });
