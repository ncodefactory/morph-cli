import keyMirror from 'keymirror';

const ActionTypes = keyMirror({
  SET_SERVER_STATE: null,
  SET_SERVER_ERROR: null,
  SET_SERVER_WORK_MODE: null,
  SET_SERVER_ENGINE: null,
  SET_SERVER_WAITING: null,
});

const setServerWorkMode = payload => ({
  type: ActionTypes.SET_SERVER_WORK_MODE,
  payload,
});
const setServerState = payload => ({
  type: ActionTypes.SET_SERVER_STATE,
  payload,
});
const setServerError = payload => ({
  type: ActionTypes.SET_SERVER_ERROR,
  payload,
});
const setServerEngine = payload => ({
  type: ActionTypes.SET_SERVER_ENGINE,
  payload,
});
const setServerWaiting = payload => ({
  type: ActionTypes.SET_SERVER_WAITING,
  payload,
});

export {
  ActionTypes, setServerState, setServerError, setServerWorkMode, setServerEngine, setServerWaiting,
};
