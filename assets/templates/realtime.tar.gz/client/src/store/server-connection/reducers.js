import { combineReducers } from 'redux';
import { ActionTypes } from './actions';

const initialState = {};

const serverConnection = (state = initialState, { type, payload }) => {
  switch (type) {
    case ActionTypes.SET_SERVER_CONNECTION_STATE:
      return { ...state, serverConnectionState: payload };
    default:
      return state;
  }
};

export default combineReducers({ serverConnection });
