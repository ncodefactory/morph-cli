import broadcast from '../server-state-dispatcher';
import env from '../../environment';
import { logDebug } from '../../logger';

let socket;
let interval;

const readyStateToString = (readyState) => {
  switch (readyState) {
    case 0:
      return 'CONNECTING';
    case 1:
      return 'OPEN';
    case 2:
      return 'CLOSING';
    case 3:
      return 'CLOSED';
    default:
      return 'CLOSED';
  }
};

const connect = (actionTypes, dispatch) => {
  socket = new WebSocket(`ws://${env.SERVER_HOST}:${env.SERVER_PORT}`);
  logDebug(`Server connection created to: ${env.SERVER_HOST}:${env.SERVER_PORT}`);

  socket.addEventListener('open', () => {
    if (interval != null) {
      clearInterval(interval);
      interval = null;
    }
    dispatch({
      type: actionTypes.SET_SERVER_CONNECTION_STATE,
      payload: readyStateToString(socket.readyState),
    });
  });

  socket.addEventListener('close', () => {
    dispatch({
      type: actionTypes.SET_SERVER_CONNECTION_STATE,
      payload: readyStateToString(socket.readyState),
    });
    if (interval == null) {
      interval = setInterval(() => {
        connect(
          actionTypes,
          dispatch,
        );
      }, env.SERVER_RECONNECT_INTERVAL);
    }
  });

  socket.addEventListener('error', (error) => {
    dispatch({
      type: actionTypes.SET_SERVER_CONNECTION_STATE,
      payload: `error: ${error.message}`,
    });
  });

  socket.addEventListener('message', (event) => {
    broadcast(JSON.parse(event.data), dispatch);
  });
};

const send = (action) => {
  socket.send(JSON.stringify(action));
};

export { connect, send };
