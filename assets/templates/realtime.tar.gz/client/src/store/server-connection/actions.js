import keyMirror from 'keymirror';
import { connect } from './connection';

const ActionTypes = keyMirror({
  SET_SERVER_CONNECTION_STATE: null,
});

const connectToServer = () => (dispatch) => {
  connect(
    ActionTypes,
    dispatch,
  );
};

export { ActionTypes, connectToServer };
