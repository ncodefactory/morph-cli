import { send } from './server-connection/connection';

const middleware = ({ getState }) => next => (action) => {
  if (action.meta && action.meta.remote) {
    const { clientId } = getState().clientInfo.clientInfo;
    send({ ...action, clientId });
  }

  return next(action);
};

export default middleware;
