import { uuid4 } from 'fast-uuid';

const getClientId = () => {
  let id = localStorage.getItem('clientId');
  if (!id) {
    id = uuid4();
    localStorage.setItem('clientId', id);
  }
  return id;
};

// eslint-disable-next-line import/prefer-default-export
export { getClientId };
