import keyMirror from 'keymirror';

const ActionTypes = keyMirror({
  SET_CLIENT_ID: null,
});

const setClientId = payload => ({
  type: ActionTypes.SET_CLIENT_ID,
  payload,
});

export { ActionTypes, setClientId };
