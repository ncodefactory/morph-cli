import { combineReducers } from 'redux';
import { ActionTypes } from './actions';

const clientInfo = (state = null, { type, payload }) => {
  switch (type) {
    case ActionTypes.SET_CLIENT_ID:
      return { ...state, clientId: payload };
    default:
      return state;
  }
};

export default combineReducers({ clientInfo });
