import serverInfoDispatcher from './server-info/dispatcher';

const broadcast = (serverState, dispatch) => {
  serverInfoDispatcher(serverState.serverInfo.serverInfo, dispatch);
};

export default broadcast;
