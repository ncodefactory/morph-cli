import { combineReducers } from 'redux';
import serverConnection from './server-connection/reducers';
import serverInfo from './server-info/reducers';
import clientInfo from './client-id/reducers';

const reducers = {
  serverConnection,
  serverInfo,
  clientInfo,
};
export default combineReducers(reducers);
