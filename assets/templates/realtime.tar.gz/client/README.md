# $NAME$-client

$NAME$-client - $NAME$ app client created using morph-cli

## Configuration

You can add .env file in you service home directory with settings:

```
PORT=your_preferred_listening_port_for_this_app (3000 default) // for development server only
REACT_APP_SERVER_HOST=your_default_server_host (127.0.0.1 default)
REACT_APP_SERVER_PORT=your_default_server_port (8090 default)
REACT_APP_SERVER_RECONNECT_INTERVAL=milliseconds_interval_to_reconnect_to_server (60000 default)
REACT_APP_LOG_LEVEL=log_level (DEBUG default, available DEBUG, TRACE, ERROR, NONE)
```

If no configuration is provided then the service listens by default on port 8090
