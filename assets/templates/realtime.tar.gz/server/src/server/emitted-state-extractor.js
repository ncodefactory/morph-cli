const extract = state => state;

export default extract;
