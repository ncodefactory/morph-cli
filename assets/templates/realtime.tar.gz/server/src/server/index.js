import WebSocket from 'ws';
import info, { logDebug } from '../logger';
import env from '../environment';

import extract from './emitted-state-extractor';

let sent = null;
const compare = (state) => {
  const toSend = JSON.stringify(state);
  if (sent === toSend) {
    return null;
  }

  sent = toSend;
  return state;
};

const startServer = (store) => {
  const wss = new WebSocket.Server({ port: env.PORT });
  wss.on('connection', (ws) => {
    ws.on('message', (message) => {
      store.dispatch(JSON.parse(message));
    });

    const state = store.getState();
    const extracted = extract(state);
    logDebug('EMIT STATE FOR 1 client', JSON.stringify(extracted));
    ws.send(JSON.stringify(extracted));
  });

  store.subscribe(() => {
    if (wss.clients && wss.clients.size > 0) {
      const state = store.getState();
      const compared = compare(extract(state));
      if (compared) {
        logDebug(`EMIT STATE FOR ${wss.clients.size} clients`, JSON.stringify(compared));
        wss.clients.forEach((client) => {
          if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify(compared));
          }
        });
      }
    }
  });

  info(`SERVER STARTED AND LISTENING ON PORT: ${env.PORT}`);
};

export default startServer;
