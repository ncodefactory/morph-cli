import keyMirror from 'keymirror';

const ServerStates = keyMirror({
  DISABLED: null,
  IDLE: null,
  BUSY: null,
  ERROR: null,
});

const ServerWorkModes = keyMirror({
  ADMIN: null,
  USER: null,
});

export {
  ServerStates,
  ServerWorkModes,
};
