require('dotenv').config();

const setStringValue = (value, defaultStringValue) => value || defaultStringValue;
const setNumberValue = (value, defaultNumberValue) => {
  const numberValue = Number(value);
  return value == null || value === '' || Number.isNaN(value) || Number.isNaN(numberValue)
    ? defaultNumberValue
    : numberValue;
};
const setBoolValue = (value, defaultBoolValue) => {
  const boolTrue = String(value).toLowerCase() === 'true';
  const boolFalse = String(value).toLowerCase() === 'false';

  return boolTrue || boolFalse ? !!boolTrue : defaultBoolValue;
};

const environment = {
  PORT: setNumberValue(process.env.PORT, 8090),
  LOG_LEVEL: process.env.LOG_LEVEL || 1,
};

export default environment;
