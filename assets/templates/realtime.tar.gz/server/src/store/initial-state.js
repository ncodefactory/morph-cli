import { moduleVersion } from '../app-info';
import { ServerWorkModes, ServerStates } from '../dictionaries';

const initialState = {
  serverInfo: {
    serverInfo: {
      state: ServerStates.DISABLED,
      mode: ServerWorkModes.ADMIN,
      engine: moduleVersion,
    },
  },
};

export default initialState;
