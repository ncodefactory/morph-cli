import { createStore, applyMiddleware, compose } from 'redux';
import thunk from 'redux-thunk';
import rootReducer from './reducers';
import initialState from './initial-state';
import logger from './logger-middleware';
import remoteActionsRouter from './remote-actions-router-middleware';
import {setServerState} from './server-info/actions' ;
import { ServerStates } from '../dictionaries';

const store = createStore(
  rootReducer,
  initialState,
  compose(
    applyMiddleware(remoteActionsRouter),
    applyMiddleware(thunk),
    applyMiddleware(logger),
  ),
);

store.dispatch(setServerState(ServerStates.IDLE))

export default store;
