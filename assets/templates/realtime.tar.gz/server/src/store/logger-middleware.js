import { logDebug } from '../logger';

const middleware = () => next => (action) => {
  const remote = action.meta && action.meta.remote ? 'REMOTE ' : undefined;
  const clientId = remote ? `, CLIENT_ID: ${action.clientId}` : '';
  logDebug(`${remote || ''}ACTION: ${action.type}${clientId}`, action.payload);
  next(action);
};
export default middleware;
