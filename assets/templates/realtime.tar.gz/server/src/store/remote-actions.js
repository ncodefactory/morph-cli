import keyMirror from 'keymirror';

const RemoteActionTypes = keyMirror({
  CHANGE_SERVER_WORK_MODE: null,
  PING_SERVER: null,
  CLEAR_SERVER_ERROR: null,
  TEST_SERVER_ERROR: null,
});

const changeServerWorkMode = workMode => ({
  type: RemoteActionTypes.CHANGE_SERVER_WORK_MODE,
  payload: workMode,
  meta: { remote: true },
});

const pingServer = () => ({
  type: RemoteActionTypes.PING_SERVER,
  meta: { remote: true },
});

const clearServerError = () => ({
  type: RemoteActionTypes.CLEAR_SERVER_ERROR,
  meta: { remote: true },
});

const testServerError = () => ({
  type: RemoteActionTypes.TEST_SERVER_ERROR,
  meta: { remote: true },
});
export {
  RemoteActionTypes,
  changeServerWorkMode,
  pingServer,
  clearServerError,
  testServerError,
};
