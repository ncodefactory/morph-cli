import translate from './remote-actions-translator';

const middleware = ({ getState, dispatch }) => next => (action) => {
  if (action.meta && action.meta.remote) {
    translate(getState, action, dispatch);
  }

  next(action);
};
export default middleware;
