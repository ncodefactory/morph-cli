import { describe, it } from 'mocha';
import { expect } from 'chai';
import reducer from './reducers';
import {
  ActionTypes, setServerState, setServerWorkMode, setServerError,
} from './actions';
import { ServerStates, ServerWorkModes } from '../../dictionaries';
import { moduleVersion } from '../../app-info';

describe('serverInfo reducer', () => {
  const getInitialState = () => ({
    serverInfo: {
      state: ServerStates.IDLE,
      mode: ServerWorkModes.ADMIN,
      engine: moduleVersion,
      error: null,
    },
  });
  it(`handles ${ActionTypes.SET_SERVER_STATE}`, () => {
    const nextState = reducer(getInitialState(), setServerState(ServerStates.BUSY));
    expect(nextState).to.deep.equal({
      serverInfo: {
        state: ServerStates.BUSY,
        mode: ServerWorkModes.ADMIN,
        engine: moduleVersion,
        error: null,
      },
    });
  });
  it(`handles ${ActionTypes.SET_SERVER_WORK_MODE}`, () => {
    const nextState = reducer(getInitialState(), setServerWorkMode(ServerWorkModes.USER));
    expect(nextState).to.deep.equal({
      serverInfo: {
        state: ServerStates.IDLE,
        mode: ServerWorkModes.USER,
        engine: moduleVersion,
        error: null,
      },
    });
  });
  it(`handles ${ActionTypes.SET_SERVER_ERROR}`, () => {
    const errorMsg = 'Sample Error';
    const nextState = reducer(getInitialState(), setServerError(errorMsg));
    expect(nextState).to.deep.equal({
      serverInfo: {
        state: ServerStates.ERROR,
        mode: ServerWorkModes.ADMIN,
        engine: moduleVersion,
        error: errorMsg,
      },
    });
  });
});
