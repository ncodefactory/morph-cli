import { combineReducers } from 'redux';
import { ActionTypes } from './actions';
import { ServerStates, ServerWorkModes } from '../../dictionaries';
import { moduleVersion } from '../../app-info';

const initialState = {
  serverInfo: {
    state: ServerStates.IDLE,
    mode: ServerWorkModes.ADMIN,
    engine: moduleVersion,
    error: null,
  },
};
const serverInfo = (state = initialState, { type, payload }) => {
  switch (type) {
    case ActionTypes.SET_SERVER_STATE:
      return { ...state, state: payload };
    case ActionTypes.SET_SERVER_WORK_MODE:
      return { ...state, mode: payload };
    case ActionTypes.SET_SERVER_ERROR:
      return {
        ...state,
        error: payload,
        state: payload == null ? ServerStates.IDLE : ServerStates.ERROR,
      };
    default:
      return state;
  }
};

export default combineReducers({
  serverInfo,
});

export { initialState };
