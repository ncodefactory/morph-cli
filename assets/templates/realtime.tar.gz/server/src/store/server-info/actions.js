/*
 * Słownik typów, oraz kreatory akcji odpowiadających za gałąź zawierającą status ogólny maszyny
 */

import keyMirror from 'keymirror';

const ActionTypes = keyMirror({
  SET_SERVER_STATE: null,
  SET_SERVER_WORK_MODE: null,
  SET_SERVER_ERROR: null,
});

const setServerState = payload => ({
  type: ActionTypes.SET_SERVER_STATE,
  payload,
});

const setServerError = payload => ({
  type: ActionTypes.SET_SERVER_ERROR,
  payload,
});

const setServerWorkMode = payload => ({
  type: ActionTypes.SET_SERVER_WORK_MODE,
  payload,
});

const clearServerError = () => (dispatch) => {
  dispatch(setServerError(null));
};

const testServerError = () => (dispatch) => {
  dispatch(setServerError('Errors workflow test'));
};

export {
  ActionTypes, setServerWorkMode, setServerState, setServerError, clearServerError, testServerError,
};
