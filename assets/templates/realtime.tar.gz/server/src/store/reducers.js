import { combineReducers } from 'redux';
import serverInfo from './server-info/reducers';

const reducers = {
  serverInfo,
};

export default combineReducers(reducers);
