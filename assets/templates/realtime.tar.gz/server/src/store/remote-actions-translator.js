import { setServerState, setServerWorkMode, clearServerError, testServerError } from './server-info/actions';
import { RemoteActionTypes } from './remote-actions';
import { ServerStates } from '../dictionaries';

const translate = (getState, { type, payload }, dispatch) => {
  // eslint-disable-next-line default-case
  switch (type) {
    case RemoteActionTypes.CHANGE_SERVER_WORK_MODE:
      dispatch(setServerWorkMode(payload));
      break;
    case RemoteActionTypes.PING_SERVER:
      break;
    case RemoteActionTypes.CLEAR_SERVER_ERROR:
      dispatch(clearServerError());
      break;
    case RemoteActionTypes.TEST_SERVER_ERROR:
      dispatch(testServerError());
      break;
  }
};

export default translate;
