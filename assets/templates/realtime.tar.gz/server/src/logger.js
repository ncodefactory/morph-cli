/* eslint-disable no-console */
import dateFormat from 'dateformat';
import env from './environment';

const dateFormatMask = 'yyyy-mm-dd HH:MM:ss';

const logLevels = {
  NONE: 0,
  ERROR: 1,
  DEBUG: 2,
};

const logLevel = env.LOG_LEVEL;

const log = (message, data) => {
  console.log();
  console.log(`${dateFormat(new Date(), dateFormatMask)} - ${message}`);
  if (data) {
    console.log(data);
  }
};

const logInfo = (message, data) => {
  log(`INFO: ${message}`, data);
};
const logDebug = (message, data) => {
  if (logLevel >= logLevels.DEBUG) {
    log(`DEBUG: ${message}`, data);
  }
};
const logError = (message, data) => {
  if (logLevel >= logLevels.ERROR) {
    log(`ERROR: ${message}`, data);
  }
};

export default logInfo;
export { logLevels, logError, logDebug };
