import info from './logger';
import { moduleName, moduleVersion } from './app-info';
import store from './store';
import startServer from './server';

const message = `${moduleName} v${moduleVersion}`;
info(message.toUpperCase());
startServer(store);
