# $NAME$-server

$NAME$-client - $NAME$ app server created using morph-cli

## Configuration

You must add .env file in you service home directory with settings:

```
PORT=your_preferred_listening_port_for_server (8090 default)
LOG_LEVEL=log_level (DEBUG default, available DEBUG, TRACE, ERROR, NONE)
```

If no configuration is provided then the service listens by default on port 8090
