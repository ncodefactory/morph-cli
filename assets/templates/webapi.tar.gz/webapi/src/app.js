import { moduleName, moduleVersion } from './app-info';
import api from './api'; // eslint-disable-line no-unused-vars

const message = `${moduleName} v${moduleVersion}`;
console.log(message); // eslint-disable-line no-console
