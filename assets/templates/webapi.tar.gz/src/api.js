import https from 'https';
import path from 'path';
import fs from 'fs';
import Koa from 'koa';
import bodyParser from 'koa-bodyparser';
import compress from 'koa-compress';
import cors from '@koa/cors';
import favicon from 'koa-favicon';
import koaSwagger from 'koa2-swagger-ui';
import logger from 'koa-logger';
import router from './router';
import env from './environment';

const app = new Koa();
const { PORT } = env;

app.use(logger());
app.use(favicon(path.join(__dirname, '/assets/favicon.ico')));
app.use(cors());
app.use(compress());
app.use(bodyParser());
app.use(router.routes());
app.use(
  koaSwagger({
    swaggerOptions: {
      url: env.USE_SSL
        ? `https://localhost:${PORT}/swagger.json`
        : `http://localhost:${PORT}/swagger.json`,
    },
  }),
);
app.use(router.allowedMethods());

const showListenInfo = () => {
  // eslint-disable-next-line no-console
  console.log(
    `api listening on port: ${PORT} ${
      env.USE_SSL ? '(secure socket layer)' : ''
    }`,
  );
};

const buildHttpApi = () => {
  return app.listen(PORT, showListenInfo);
};

const buildHttpsApi = () => {
  const api = https.createServer(
    {
      key: fs.readFileSync(path.join(__dirname, 'certs/server.key')),
      cert: fs.readFileSync(path.join(__dirname, 'certs/server.cert')),
    },
    app.callback(),
  );
  api.listen(PORT, showListenInfo);
  return api;
};

const api = env.USE_SSL ? buildHttpsApi() : buildHttpApi();

export default api;
