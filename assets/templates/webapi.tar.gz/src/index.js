import { moduleName, moduleVersion } from './app-info';

export { moduleName, moduleVersion };
