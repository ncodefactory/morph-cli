import { name, version, description } from '../package.json';

const moduleName = name;
const moduleVersion = version;
const moduleDescription = description;

export { moduleName, moduleVersion, moduleDescription };
