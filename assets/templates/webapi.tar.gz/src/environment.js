import Wrapper from '@ncodefactory/dotenv-wrapper';

const environment = new Wrapper();

environment.addNumber('PORT', 3001);
environment.addBoolean('USE_SSL', false);

export default environment;
