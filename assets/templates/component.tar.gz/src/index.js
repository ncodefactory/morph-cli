import React from 'react';
import ReactDOM from 'react-dom';
import './index.scss';
import { $COMPONENT_NAME$ } from './lib';

ReactDOM.render(<$COMPONENT_NAME$ />, document.getElementById('root'));
